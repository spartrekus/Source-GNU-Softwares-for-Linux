enum color {RED, GREEN, BLUE};
enum color {R, G, B};

enum color c;
