enum color {RED, GREEN, BLUE};
enum rgb {RED, G, B};

enum color c = RED;
