
#ifndef EL__SCRIPTING_LUA_LUA_H
#define EL__SCRIPTING_LUA_LUA_H

struct module;

extern struct module lua_scripting_module;

#endif
