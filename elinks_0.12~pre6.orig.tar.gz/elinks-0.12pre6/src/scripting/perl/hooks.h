
#ifndef EL__SCRIPTING_PERL_HOOKS_H
#define EL__SCRIPTING_PERL_HOOKS_H

struct event_hook_info;

extern struct event_hook_info perl_scripting_hooks[];

#endif
