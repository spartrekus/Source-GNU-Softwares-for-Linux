
#ifndef EL__SCRIPTING_PERL_PERL_H
#define EL__SCRIPTING_PERL_PERL_H

struct module;

extern struct module perl_scripting_module;

#endif
