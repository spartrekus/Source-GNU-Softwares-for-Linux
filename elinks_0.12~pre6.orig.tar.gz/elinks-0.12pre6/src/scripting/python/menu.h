#ifndef EL__SCRIPTING_PYTHON_MENU_H
#define EL__SCRIPTING_PYTHON_MENU_H

#include <Python.h>

int python_init_menu_interface(PyObject *dict, PyObject *name);

#endif
