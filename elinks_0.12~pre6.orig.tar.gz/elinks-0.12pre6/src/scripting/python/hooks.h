
#ifndef EL__SCRIPTING_PYTHON_HOOKS_H
#define EL__SCRIPTING_PYTHON_HOOKS_H

struct event_hook_info;

extern struct event_hook_info python_scripting_hooks[];

#endif
