#ifndef EL__SCRIPTING_PYTHON_DIALOGS_H
#define EL__SCRIPTING_PYTHON_DIALOGS_H

#include <Python.h>

int python_init_dialogs_interface(PyObject *dict, PyObject *name);

#endif
