
#ifndef EL__SCRIPTING_PYTHON_PYTHON_H
#define EL__SCRIPTING_PYTHON_PYTHON_H

struct module;

extern struct module python_scripting_module;

#endif
