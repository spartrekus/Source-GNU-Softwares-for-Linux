#ifndef EL__SCRIPTING_PYTHON_LOAD_H
#define EL__SCRIPTING_PYTHON_LOAD_H

#include <Python.h>

int python_init_load_interface(PyObject *dict, PyObject *name);

#endif
