
#ifndef EL__SCRIPTING_GUILE_GUILE_H
#define EL__SCRIPTING_GUILE_GUILE_H

struct module;

extern struct module guile_scripting_module;

#endif
