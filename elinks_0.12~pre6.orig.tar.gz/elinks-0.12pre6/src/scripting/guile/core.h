
#ifndef EL__SCRIPTING_GUILE_CORE_H
#define EL__SCRIPTING_GUILE_CORE_H

void init_guile(struct module *module);

#endif
