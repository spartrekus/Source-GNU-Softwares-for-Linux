#ifndef EL__SCRIPTING_SMJS_KEYBINDING_H
#define EL__SCRIPTING_SMJS_KEYBINDING_H

#include "ecmascript/spidermonkey-shared.h"

void smjs_init_keybinding_interface(void);

#endif
