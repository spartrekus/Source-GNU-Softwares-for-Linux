#ifndef EL__SCRIPTING_SMJS_LOAD_URI_H
#define EL__SCRIPTING_SMJS_LOAD_URI_H

void smjs_init_load_uri_interface(void);

#endif
