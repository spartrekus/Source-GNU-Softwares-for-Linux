#ifndef EL__SCRIPTING_SMJS_GLOBHIST_H
#define EL__SCRIPTING_SMJS_GLOBHIST_H

void smjs_init_globhist_interface(void);

#endif
