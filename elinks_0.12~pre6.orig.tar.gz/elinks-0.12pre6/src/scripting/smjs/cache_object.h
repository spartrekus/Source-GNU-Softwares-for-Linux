#ifndef EL__SCRIPTING_SMJS_CACHE_H
#define EL__SCRIPTING_SMJS_CACHE_H

struct cache_entry;

JSObject *smjs_get_cache_entry_object(struct cache_entry *cached);

#endif

