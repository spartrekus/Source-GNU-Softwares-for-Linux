#ifndef EL__SCRIPTING_SMJS_ACTION_OBJECT_H
#define EL__SCRIPTING_SMJS_ACTION_OBJECT_H

void smjs_init_action_interface(void);

#endif
