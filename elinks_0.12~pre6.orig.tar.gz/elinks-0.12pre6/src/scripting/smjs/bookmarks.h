#ifndef EL__SCRIPTING_SMJS_BOOKMARKS_H
#define EL__SCRIPTING_SMJS_BOOKMARKS_H

#include "ecmascript/spidermonkey-shared.h"

void smjs_init_bookmarks_interface(void);

#endif
