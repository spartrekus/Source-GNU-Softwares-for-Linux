
#ifndef EL__SCRIPTING_RUBY_RUBY_H
#define EL__SCRIPTING_RUBY_RUBY_H

struct module;

extern struct module ruby_scripting_module;

#endif
