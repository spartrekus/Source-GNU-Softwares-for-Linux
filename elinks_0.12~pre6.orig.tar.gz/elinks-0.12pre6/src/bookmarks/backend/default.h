
#ifndef EL__BOOKMARKS_BACKEND_DEFAULT_H
#define EL__BOOKMARKS_BACKEND_DEFAULT_H

#include "bookmarks/backend/common.h"

extern struct bookmarks_backend default_bookmarks_backend;

#endif
