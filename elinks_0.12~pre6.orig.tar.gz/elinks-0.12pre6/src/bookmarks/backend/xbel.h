#ifndef EL__BOOKMARKS_BACKEND_XBEL_H
#define EL__BOOKMARKS_BACKEND_XBEL_H

#include "bookmarks/backend/common.h"

extern struct bookmarks_backend xbel_bookmarks_backend;

#endif /* !EL__BOOKMARKS_BACKEND_XBEL_H */
