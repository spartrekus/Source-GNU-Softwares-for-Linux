
#ifndef EL__PROTOCOL_REWRITE_REWRITE_H
#define EL__PROTOCOL_REWRITE_REWRITE_H

#ifdef CONFIG_URI_REWRITE

#include "main/module.h"

extern struct module uri_rewrite_module;

#endif
#endif
