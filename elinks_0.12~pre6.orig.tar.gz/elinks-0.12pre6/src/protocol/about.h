#ifndef EL__PROTOCOL_ABOUT_H
#define EL__PROTOCOL_ABOUT_H

#include "protocol/protocol.h"

extern protocol_handler_T about_protocol_handler;

#endif
