#ifndef EL__GLOBHIST_DIALOGS_H
#define EL__GLOBHIST_DIALOGS_H

#include "bfu/hierbox.h"
#include "session/session.h"

extern struct hierbox_browser globhist_browser;
void history_manager(struct session *);

#endif
