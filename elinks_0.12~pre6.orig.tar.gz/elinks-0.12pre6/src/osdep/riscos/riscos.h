
#ifndef EL__OSDEP_RISCOS_RISCOS_H
#define EL__OSDEP_RISCOS_RISCOS_H

#ifdef CONFIG_OS_RISCOS

/* TODO */

#endif

#endif
