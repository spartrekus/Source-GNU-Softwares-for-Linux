#ifndef EL__OSDEP_SYSNAME_H
#define EL__OSDEP_SYSNAME_H

extern unsigned char system_name[];

extern void get_system_name(void);

#endif
