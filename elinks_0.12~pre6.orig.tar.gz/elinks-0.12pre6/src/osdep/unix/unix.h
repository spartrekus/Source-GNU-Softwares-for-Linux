
#ifndef EL__OSDEP_UNIX_UNIX_H
#define EL__OSDEP_UNIX_UNIX_H

#ifdef CONFIG_OS_UNIX

/* TODO */

#endif

#endif
