
#ifndef EL__VERNUM_H
#define EL__VERNUM_H

extern unsigned char *build_date, *build_time, *build_id;

#endif /* EL__VERNUM_H */
