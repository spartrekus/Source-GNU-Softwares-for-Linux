
#ifndef EL__DOCUMENT_HTML_TABLES_H
#define EL__DOCUMENT_HTML_TABLES_H

struct html_context;

void format_table(unsigned char *, unsigned char *, unsigned char *, unsigned char **, struct html_context *);

#endif
