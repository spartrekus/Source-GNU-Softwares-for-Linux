#ifndef EL__UTIL_ENV_H
#define EL__UTIL_ENV_H


int env_set(unsigned char *name, unsigned char *value, int len);

#endif
