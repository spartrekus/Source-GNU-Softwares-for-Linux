#ifndef EL__UTIL_ALIGN_H
#define EL__UTIL_ALIGN_H

enum format_align {
	ALIGN_LEFT,
	ALIGN_CENTER,
	ALIGN_RIGHT,
	ALIGN_JUSTIFY,
};

#endif
