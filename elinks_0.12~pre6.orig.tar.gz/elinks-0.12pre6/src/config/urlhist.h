#ifndef EL__CONFIG_URLHIST_H
#define EL__CONFIG_URLHIST_H

#include "bfu/inphist.h"

struct module;

extern struct input_history goto_url_history;
extern struct module goto_url_history_module;

#endif
