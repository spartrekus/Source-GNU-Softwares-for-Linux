#ifndef EL__CONFIG_TIMER_H
#define EL__CONFIG_TIMER_H

struct module;

extern struct module periodic_saving_module;

#endif
