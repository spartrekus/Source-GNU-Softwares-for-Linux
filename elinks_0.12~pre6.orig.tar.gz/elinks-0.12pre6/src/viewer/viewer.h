#ifndef EL__VIEWER_VIEWER_H
#define EL__VIEWER_VIEWER_H

struct module;

extern struct module viewer_module;

#endif
